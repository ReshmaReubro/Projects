<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RelatedWorkVideo extends Model
{
    //
}
