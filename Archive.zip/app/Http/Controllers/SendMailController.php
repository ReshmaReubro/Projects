<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\URL;

use App\Mail\ContactForm;

class SendMailController extends Controller
{
    public function send()
    {
    
    	$this->validate(Request(), [
	        'name' => 'required|min:3',
	        'email' => 'required|email',
	        'phone' => 'required',
	        'message' => 'required',
            'WhatIsItRegarding' => 'required',
            'g-recaptcha-response' => 'required|captcha'
	        ]);



    	$mailable = new ContactForm;

		$mailable->replyTo(Request('email'),Request('name'));
		$mailable->subject(Request('subject'));


	    \Mail::to('support@designsbyps.com')->send($mailable);

        if(\Mail::failures())
        {
            $notification = array(
            'message' => 'Oops! Something went wrong', 
            'alert-type' => 'error'
            );

            
            return Redirect::to(URL::previous()."#contact-us-section")->with($notification);

        }
        else
        {
            $notification = array(
            'message' => 'Thanks! We shall get back to you soon.', 
            'alert-type' => 'success'
            );

        }


        return redirect()->back()->with($notification);

	    


    }
}
