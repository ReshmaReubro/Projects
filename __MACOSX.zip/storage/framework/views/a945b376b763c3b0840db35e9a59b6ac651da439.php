<section class="vertical-scrolling text-center" id="our-services" >
  <?php echo $__env->make('layouts.top-small-logo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="container-fluid services-rectangular">
    <div class="row">
      <div class="pt-60 visible-sm"></div>

      
      
      <div class="col-lg-12 col-md-12 col-xs-10 col-md-offset-0 col-lg-offset-0 col-xs-offset-1">
        <div class="isotope columns-3 popup-gallery mt-10">
          <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(URL::asset('services/'.$service->slug)); ?>">
              <div class="grid-item">
                <div class="portfolio-item  rectangular-portfolio">


                  <img class="img-responsive" src="<?php echo e(Storage::url('/'.explode('.',$service->image)[0].'-cropped.'.pathinfo($service->image, PATHINFO_EXTENSION))); ?>" alt="<?php echo e($service->slug); ?>">
                  <div class="portfolio-overlay">
                    <h5 class="text-white"> <?php echo e(title_case($service->name)); ?> </h5>
                    <span class="text-white"> <?php echo e($service->description); ?>

                    </span>  
                  </div>
                </div>
              </div>
            </a>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>

      

    </div>
    <h3 class="custom-section-footer">Our Services</h3>
  </div>
</section>

