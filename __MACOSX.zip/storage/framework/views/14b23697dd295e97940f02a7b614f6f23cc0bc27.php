<!--=================================
 preloader -->
 
<div id="pre-loader">
    <img src="<?php echo e(URL::asset('images/pre-loader/custom.gif')); ?>" alt="preloader image">
</div>
<!--=================================
 preloader -->