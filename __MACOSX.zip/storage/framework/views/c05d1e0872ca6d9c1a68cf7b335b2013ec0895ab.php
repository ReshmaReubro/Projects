<section class="vertical-scrolling text-center" id="our-clients"  >

	<?php echo $__env->make('layouts.top-small-logo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	

	<div class="container">
		<div class="row mt-60 mb-60">
      <div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 "></div>
      <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10 ">

        <div class="slick-client-slider">


          <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <img src="<?php echo e(Storage::url('/'.explode('.',$client->image)[0].'-cropped.'.pathinfo($client->image, PATHINFO_EXTENSION))); ?>" alt="<?php echo e($client->image_alt_tag); ?>"/>
        
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          
          

        </div>

      </div>
      <div class="col-lg-1 col-md-1 col-sm-1 col-xs-1"></div>
    </div>
  </div>

  <h3 class="custom-section-footer">Our Clients</h3>

</section>