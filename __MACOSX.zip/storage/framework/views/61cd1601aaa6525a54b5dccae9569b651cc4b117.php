<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="icon" type="image/png" href="<?php echo e(URL::asset('favicon.png')); ?>" />

  <title><?php echo e($page_title); ?> | <?php echo e($page_name); ?> | <?php echo e($site_name); ?></title>
  <meta name="description" content="<?php echo e($page_description); ?>" />

  

  


  <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/plugins-css.css')); ?>" />
  
  

  <!-- Shortcodes -->
  <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/shortcodes/combined.css')); ?>" />

  <!-- Style -->
  <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/style.css')); ?>" />

  
  

  

  <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/custom.css')); ?>" /> 

    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/skins/skin-gray.css')); ?>" /> 






    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <![endif]-->
  </head>
  <body class="st-container st-effect-1">

    <?php echo $__env->make('layouts.preloader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    

    <?php echo $__env->make('layouts.sidepanel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


  <div class="st-pusher">
   
   <?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


  <div class="text-center small-top-centered-logo-single-work visible-xs">
          <a href="<?php echo e(URL::asset('/#home-section')); ?>"><img class="text-center" src="<?php echo e(URL::asset('images/custom/logo_xs.png')); ?>" alt="PS & COMPANY Logo" ></a>
  </div>


  <div class="text-center small-top-centered-logo-single-work hidden-xs">
          <a href="<?php echo e(URL::asset('/#home-section')); ?>"><img class="text-center" src="<?php echo e(URL::asset('images/custom/logo_small.png')); ?>" alt="PS & COMPANY Logo" ></a>
  </div>





  <div class="mb-20 hidden-xs">&nbsp;</div>




  <section class="page-section-ptb">
      <div class="container">
        <div class="row">
        <div class="col-lg-12 col-md-12">

          
          
          <div class="isotope columns-4 popup-gallery mt-70">
              


               <?php $__currentLoopData = $works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
               
                <a href="<?php echo e(URL::asset('services/'.$service_slug.'/'.$work->slug)); ?>">
                  <div class="grid-item">
                  <div class="portfolio-item">
                   <img src="<?php echo e(Storage::url('/'.explode('.',$work->image)[0].'-cropped.'.pathinfo($work->image, PATHINFO_EXTENSION))); ?>" alt="<?php echo e($work->slug); ?>">
                     <div class="portfolio-overlay">
                        <h4 class="text-white"><?php echo e(title_case($work->name)); ?> </h4>
                      <span class="text-white"> <?php echo e($work->description); ?>

                      </span>  
                      </div>
                    
                  </div>
                  </div>
                </a>

               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


              
              </div>
          </div>
     </div>


    
      </div>

    </section>




<!-- js files -->
<script src="<?php echo e(URL::asset('js/jquery.js')); ?>"></script>






<script type="text/javascript" src="<?php echo e(URL::asset('js/plugins-jquery.js')); ?>"></script>




<!-- plugin_path -->
<script type="text/javascript">
var plugin_path = "<?php echo URL::asset('js'); ?>/"
</script>


<!-- custom -->
<script type="text/javascript" src="<?php echo e(URL::asset('js/custom.js')); ?>"></script>



</body>
</html>