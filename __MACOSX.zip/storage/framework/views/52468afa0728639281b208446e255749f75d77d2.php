<header class="header burger">
     <div class="container-fluid" style="height: 0;">
      <div class="row" style="height: 0;"> 
        <div class="col-xs-4" style="margin-top: 30px;">
          <div class="social-icons border small  social-icons-dark hidden-sm hidden-xs clearfix">
            <ul>
              <li class="social-facebook"><a href="https://www.facebook.com/psandcmpny" target="_blank"><i class="fa fa-facebook "></i></a></li>

              <li class="social-twitter"><a href="https://twitter.com/company_ps" target="_blank"><i class="fa fa-twitter"></i></a></li>
              
              <li class="social-linkedin"><a href="https://www.linkedin.com/in/ps-and-company-dwc-llc-b76a5b119" target="_blank"><i class="fa fa-linkedin"></i></a></li>

              <li class="social-vimeo"><a href="https://vimeo.com/user50777905" target="_blank"><i class="fa fa-vimeo"></i></a></li>

              <li class="social-instagram"><a href="https://www.instagram.com/psandcompny/" target="_blank"><i class="fa fa-instagram"></i></a></li>

              <li class="social-youtube"><a href="https://www.youtube.com/channel/UCIJndm1_7ShB4e1sCG3-1pg" target="_blank"><i class="fa fa-youtube"></i></a></li>

            </ul>
          </div>

        </div>
        <div class="col-xs-4 pull-right text-right" style="margin-top: 30px;">
          <a href="#" class="menu-icon medium side-panel-trigger"><span class="ti-menu theme-color"></span></a> 
        </div>
      </div>
    </div>
  </header>