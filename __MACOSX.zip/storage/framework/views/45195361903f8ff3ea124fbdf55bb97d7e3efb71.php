<?php $__env->startComponent('mail::layout'); ?>
   <?php $__env->slot('header'); ?>
        <?php $__env->startComponent('mail::header', ['url' => config('app.url')]); ?>
            Contact Form
        <?php echo $__env->renderComponent(); ?>
    <?php $__env->endSlot(); ?>





<?php $__env->startComponent('mail::table'); ?>
| Label       | Data         
| ------------- |:-------------:
| Name      | <?php echo e(Request('name')); ?>  
| Email      | <?php echo e(Request('email')); ?>  
| Phone      | <?php echo e(Request('phone')); ?>

| Regarding      | <?php echo e(Request('WhatIsItRegarding')); ?>    
| Message      | <?php echo e(Request('message')); ?>    
<?php echo $__env->renderComponent(); ?>

 	<?php $__env->slot('footer'); ?>
        <?php $__env->startComponent('mail::footer'); ?>
            Email from Designsbyps.com Contact Form
        <?php echo $__env->renderComponent(); ?>
    <?php $__env->endSlot(); ?>


<?php echo $__env->renderComponent(); ?>
