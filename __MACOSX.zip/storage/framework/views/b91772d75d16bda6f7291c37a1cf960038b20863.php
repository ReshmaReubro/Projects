

<div class="custom-section-header hidden-xs" >
	<a href="<?php echo e(URL::asset('/#home-section')); ?>"><img  src="<?php echo e(URL::asset('images/custom/logo_small.png')); ?>" alt="PS & COMPANY Logo" ></a>
</div>

<div class="custom-section-header visible-xs"  >
	<a href="<?php echo e(URL::asset('/#home-section')); ?>"><img  src="<?php echo e(URL::asset('images/custom/logo_xs.png')); ?>" alt="PS & COMPANY Logo" ></a>
</div>