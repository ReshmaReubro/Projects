import AppListing from '../app-components/Listing/AppListing';

Vue.component('service-listing', {
    mixins: [AppListing]
});