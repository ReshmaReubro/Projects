

<div class="custom-section-header hidden-xs" >
	<a href="{{URL::asset('/#home-section')}}"><img  src="{{URL::asset('images/custom/logo_small.png')}}" alt="PS & COMPANY Logo" ></a>
</div>

<div class="custom-section-header visible-xs"  >
	<a href="{{URL::asset('/#home-section')}}"><img  src="{{URL::asset('images/custom/logo_xs.png')}}" alt="PS & COMPANY Logo" ></a>
</div>