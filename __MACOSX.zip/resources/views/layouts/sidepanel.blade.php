<div class="st-menu st-effect-1 right-side " id="menu-1" >

  <div class="pos-top mt-40 text-right mr-40 ham-close">
    <ul class="list-unstyled"><li><a href="#" ><i class="ti ti-close side-panel-trigger ham-big-close" ></i></a></li></ul>
  </div>
      <div class="pos-bot mt-80 text-center">
        <ul class="menu side-panel-link-trigger">
          <li><a class="side-panel-link-trigger" href="{{URL::asset('/#home-section')}}">Home </a></li>
          <li><a class="side-panel-link-trigger" href="{{URL::asset('/#about-us-section')}}">About us</a></li>
          <li><a class="side-panel-link-trigger" href="{{URL::asset('/#our-services-section')}}">Our Services</a></li>
          <li><a class="side-panel-link-trigger" href="{{URL::asset('/#our-clients-section')}}">Our Clients</a></li>
          <li><a class="side-panel-link-trigger" href="{{URL::asset('/#contact-us-section')}}">Contact us</a></li>
        </ul>
        <div class="slide-footer">
          
          
         <div class="copy-right pos-top">
          <div class="social-icons border small  social-icons-dark clearfix text-center">
            <ul>
              <li class="social-facebook"><a href="https://www.facebook.com/psandcmpny" target="_blank"><i class="fa fa-facebook "></i></a></li>

              <li class="social-twitter"><a href="https://twitter.com/company_ps" target="_blank"><i class="fa fa-twitter"></i></a></li>
              
              <li class="social-linkedin"><a href="https://www.linkedin.com/in/ps-and-company-dwc-llc-b76a5b119" target="_blank"><i class="fa fa-linkedin"></i></a></li>

              <li class="social-vimeo"><a href="https://vimeo.com/user50777905" target="_blank"><i class="fa fa-vimeo"></i></a></li>

              <li class="social-instagram"><a href="https://www.instagram.com/psandcompny/" target="_blank"><i class="fa fa-instagram"></i></a></li>

              <li class="social-youtube"><a href="https://www.youtube.com/channel/UCIJndm1_7ShB4e1sCG3-1pg" target="_blank"><i class="fa fa-youtube"></i></a></li>

              

            </ul>
          </div>
          <div class="copy-right">
        <p class="mt-15 fw-1 small-copy-right">  <a href="{{URL::asset('/#home-section')}}"> PS & COMPANY </a>  ALL RIGHTS RESERVED </p>
      </div>

        </div>
      </div>
    </div>
  </div>