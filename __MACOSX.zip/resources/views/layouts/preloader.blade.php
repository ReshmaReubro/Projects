<!--=================================
 preloader -->
 
<div id="pre-loader">
    <img src="{{URL::asset('images/pre-loader/custom.gif')}}" alt="preloader image">
</div>
<!--=================================
 preloader -->