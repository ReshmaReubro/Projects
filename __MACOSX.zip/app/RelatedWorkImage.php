<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RelatedWorkImage extends Model
{
    //
}
